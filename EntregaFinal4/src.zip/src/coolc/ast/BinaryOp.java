package coolc.ast;

public enum BinaryOp {
    PLUS, MINUS, MULT, DIV,
    LT, LTE, EQUALS
}
