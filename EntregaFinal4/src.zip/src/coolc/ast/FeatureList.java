package coolc.ast;

import java.util.ArrayList;

public class FeatureList extends ArrayList<Feature> {
    public FeatureList(Feature f) {
        this.add(f);
    }
}