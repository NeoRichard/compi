package coolc.ast;

public abstract class Feature extends Node {
    
}