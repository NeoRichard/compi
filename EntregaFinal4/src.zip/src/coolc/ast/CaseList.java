package coolc.ast;

import java.util.ArrayList;

public class CaseList extends ArrayList<Case> {
    public CaseList(Case c) {
        this.add(c);
    }
}