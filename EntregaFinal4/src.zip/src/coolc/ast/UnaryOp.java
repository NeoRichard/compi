package coolc.ast;

public enum UnaryOp {
    ISVOID, NEGATE, NOT
}
